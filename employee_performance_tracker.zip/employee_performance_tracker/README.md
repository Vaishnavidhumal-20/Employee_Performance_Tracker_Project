This project is an Employee Performance Tracker System designed to manage employee data in an IT company. It will record and analyze key information such as employee name, department, hours worked, tasks completed, and performance rating.



Project Objectives:
1	Store and manage employee data (CSV-based).
2	Analyze employee performance and find top performers.
3	Visualize employee productivity using charts.
4	Use OOP, Functions, and File Handling concepts from Python Phase 1.
5	Provide a simple, interactive console interface.
