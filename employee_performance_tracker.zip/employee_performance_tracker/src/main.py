from .storage import load_employees, save_employee, export_top_performer
from .analysis import top_performer, average_rating, average_tasks, employee_of_the_month
from .visualize import plot_performance, plot_tasks_vs_rating
from .employee import Employee

def menu():
    while True:
        print("\n=== Employee Performance Tracker ===")
        print("1. View Employees")
        print("2. Add Employee")
        print("3. Show Top Performer")
        print("4. Show Averages")
        print("5. Visualize Performance")
        print("6. Employee of the Month")
        print("7. Tasks vs Rating Chart")
        print("8. Exit")

        choice = input("Enter choice: ")
        employees = load_employees()

        if choice == '1':
            for e in employees:
                print(e)

        elif choice == '2':
            name = input("Name: ")
            dept = input("Department: ")
            hrs = float(input("Hours Worked: "))
            tasks = int(input("Tasks Completed: "))
            rating = float(input("Rating: "))
            emp = Employee(name, dept, hrs, tasks, rating)
            save_employee(emp)
            print("Employee added successfully!")

        elif choice == '3':
            top = top_performer(employees)
            print(f"\n Top Performer: {top.name} (Score: {top.performance_score():.2f})")
            export_top_performer(top)
            print(" Top performer data exported to data/top_performer.csv")

        elif choice == '4':
            print(f"Average Rating: {average_rating(employees):.2f}")
            print(f" Average Tasks: {average_tasks(employees):.2f}")

        elif choice == '5':
            plot_performance(employees)

        elif choice == '6':
            month_emp = employee_of_the_month(employees)
            print(f"\n Employee of the Month: {month_emp.name} (Department: {month_emp.department})")
            print(f"Performance Score: {month_emp.performance_score():.2f}")

        elif choice == '7':
            plot_tasks_vs_rating(employees)

        elif choice == '8':
            print("Goodbye!")
            break

        else:
            print("Invalid choice. Try again!")

if __name__ == "__main__":
    menu()
