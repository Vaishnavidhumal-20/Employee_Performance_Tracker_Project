import csv
from .employee import Employee

FILE_PATH = "data/employees.csv"
TOP_FILE_PATH = "data/top_performer.csv"

def load_employees():
    employees = []
    with open(FILE_PATH, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            employees.append(Employee(**row))
    return employees

def save_employee(emp):
    with open(FILE_PATH, 'a', newline='') as csvfile:
        fieldnames = ['name', 'department', 'hours_worked', 'tasks_completed', 'rating']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writerow({
            'name': emp.name,
            'department': emp.department,
            'hours_worked': emp.hours_worked,
            'tasks_completed': emp.tasks_completed,
            'rating': emp.rating
        })

def export_top_performer(top_emp):
    """Export top performer details into a new CSV file"""
    with open(TOP_FILE_PATH, 'w', newline='') as csvfile:
        fieldnames = ['name', 'department', 'hours_worked', 'tasks_completed', 'rating', 'performance_score']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow({
            'name': top_emp.name,
            'department': top_emp.department,
            'hours_worked': top_emp.hours_worked,
            'tasks_completed': top_emp.tasks_completed,
            'rating': top_emp.rating,
            'performance_score': top_emp.performance_score()
        })
