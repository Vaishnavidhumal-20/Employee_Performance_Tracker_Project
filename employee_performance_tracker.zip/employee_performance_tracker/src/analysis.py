def top_performer(employees):
    return max(employees, key=lambda e: e.performance_score())

def average_rating(employees):
    return sum(e.rating for e in employees) / len(employees)

def average_tasks(employees):
    return sum(e.tasks_completed for e in employees) / len(employees)

def employee_of_the_month(employees):
    """Select Employee of the Month based on performance score and hours worked"""
    return max(employees, key=lambda e: (e.performance_score(), e.hours_worked))
