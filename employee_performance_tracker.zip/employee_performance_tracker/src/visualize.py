import matplotlib.pyplot as plt

def plot_performance(employees):
    names = [e.name for e in employees]
    scores = [e.performance_score() for e in employees]

    plt.bar(names, scores, color='skyblue')
    plt.title("Employee Performance Scores")
    plt.xlabel("Employee")
    plt.ylabel("Performance Score")
    plt.xticks(rotation=30)
    plt.tight_layout()
    plt.show()

def plot_tasks_vs_rating(employees):
    """Scatter plot: Tasks Completed vs Rating"""
    tasks = [e.tasks_completed for e in employees]
    ratings = [e.rating for e in employees]
    names = [e.name for e in employees]
    1

    plt.scatter(tasks, ratings, color='green')
    for i, name in enumerate(names):
        plt.text(tasks[i]+0.1, ratings[i], name, fontsize=8)

    plt.title("Tasks Completed vs Rating")
    plt.xlabel("Tasks Completed")
    plt.ylabel("Rating")
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.show()
